import UIKit

struct BankAccount {
    private(set) var funds = 0

    mutating func deposit(amount: Int) {
        funds += amount
    }

    mutating func withdraw(amount: Int) -> Bool {
        if funds >= amount {
            funds -= amount
            return true
        } else {
            return false
        }
    }
}

var account = BankAccount()
account.deposit(amount: 100)
let success = account.withdraw(amount: 200)

if success {
    print("Withdrew money successfully")
} else {
    print("Failed to get the money")
}


//account.funds -= 1000
print(account.funds)


struct FacebookUser {
    private var privatePosts: [String]
    public var publicPosts: [String]
    
    init(privatePosts: [String] = [], publicPosts: [String] = []) {
        self.privatePosts = privatePosts
        self.publicPosts = publicPosts
    }
}

let user = FacebookUser()


struct Office {
    private var passCode: String
    var address: String
    var employees: [String]
    init(address: String, employees: [String]) {
        self.address = address
        self.employees = employees
        self.passCode = "SEKRIT"
    }
}
let monmouthStreet = Office(address: "30 Monmouth St", employees: ["Paul Hudson"])


struct School {
    nonisolated(unsafe) static var studentCount = 0

    static func add(student: String) {
        print("\(student) joined the school.")
        studentCount += 1
    }
}

School.add(student: "Taylor Swift")
print(School.studentCount)

School.add(student: "doy ewo")
print(School.studentCount)


struct Raffle {
    var ticketsUsed = 0
    var name: String
    var tickets: Int
    init(name: String, tickets: Int) {
        self.name = name
        self.tickets = tickets
        self.ticketsUsed += tickets
    }
}

